# Helpful Links

## Markdown
- https://www.markdowntutorial.com/
- https://www.markdownguide.org/cheat-sheet/

## Git & GitHub
- https://learngitbranching.js.org/
- https://docs.github.com/en

## Database Learning
- https://sqlbolt.com/
- https://www.db-fiddle.com/

## AWS Services
- https://docs.aws.amazon.com/
- https://explore.skillbuilder.aws/ (AWS training)
